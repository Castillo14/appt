<?php 

$conn= new mysqli('localhost','urafnghd_root','reniertrenuela9','urafnghd_moral')or die("Could not connect to mysql".mysqli_error($con));
